const chooseButtons = document.querySelectorAll(".choose-btn");
const orderFormSection = document.getElementById("order-form-section");
const selectedProductName = document.getElementById("selectedProductName");

chooseButtons.forEach(button => {
    button.addEventListener("click", () => {
        const productCard = button.closest(".product-card");
        const productName = productCard.dataset.productName;
        selectedProductName.textContent = productName;
        orderFormSection.style.display = "block";
        orderFormSection.scrollIntoView({ behavior: "smooth" });
    });
});

const orderForm = document.getElementById("orderForm");
orderForm.addEventListener("submit", function(e) {
    e.preventDefault();
    const orderId = "ORD" + Math.floor(1000 + Math.random() * 9000);
    const fileInput = document.getElementById("referenceImageUpload");
    let imageBase64 = "No image uploaded";
    if(fileInput.files[0]) {
        const reader = new FileReader();
        reader.onload = function() {
            imageBase64 = reader.result;
            saveOrder(orderId, imageBase64);
        };
        reader.readAsDataURL(fileInput.files[0]);
    } else {
        saveOrder(orderId, imageBase64);
    }
});

function saveOrder(orderId, image) {
    const orderData = {
        orderId: orderId,
        product: selectedProductName.textContent,
        name: document.getElementById("customerName").value,
        email: document.getElementById("customerEmail").value,
        phone: document.getElementById("customerPhone").value,
        measurements: {
            chest: document.getElementById("measurement_chest").value,
            waist: document.getElementById("measurement_waist").value,
            hips: document.getElementById("measurement_hips").value,
            shoulder: document.getElementById("measurement_shoulder").value,
            sleeve: document.getElementById("measurement_sleeve").value,
            length: document.getElementById("measurement_length").value,
            other: document.getElementById("measurement_other").value
        },
        address: {
            line1: document.getElementById("address_line1").value,
            line2: document.getElementById("address_line2").value,
            city: document.getElementById("address_city").value,
            state: document.getElementById("address_state").value,
            zip: document.getElementById("address_zip").value,
            country: document.getElementById("address_country").value
        },
        image: image,
        status: "Order Placed"
    };
    localStorage.setItem(orderId, JSON.stringify(orderData));
    window.location.href = `order-confirmation.html?orderId=${orderId}`;
}
